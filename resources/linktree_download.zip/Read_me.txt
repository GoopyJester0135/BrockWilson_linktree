I do not know if I need to do this but just to be safe.

All credit for any contents in these files goes to codecademy, as these are their lessons.